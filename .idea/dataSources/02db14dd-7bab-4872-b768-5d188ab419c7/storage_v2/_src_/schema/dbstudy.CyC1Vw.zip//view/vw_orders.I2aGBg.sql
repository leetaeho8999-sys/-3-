create definer = dbuser@`%` view vw_orders as
select `o`.`orderid`   AS `orderid`,
       `c`.`name`      AS `name`,
       `b`.`bookname`  AS `bookname`,
       `o`.`saleprice` AS `saleprice`,
       `o`.`orderdate` AS `orderdate`
from ((`dbstudy`.`orders` `o` left join `dbstudy`.`customer` `c`
       on ((`o`.`custid` = `c`.`custid`))) left join `dbstudy`.`book` `b` on ((`o`.`custid` = `b`.`bookid`)));

