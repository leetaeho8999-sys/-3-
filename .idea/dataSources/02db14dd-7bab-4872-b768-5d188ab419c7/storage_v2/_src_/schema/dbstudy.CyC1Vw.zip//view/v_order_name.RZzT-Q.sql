create definer = dbuser@`%` view v_order_name as
select `c`.`name` AS `name`, `o`.`saleprice` AS `saleprice`
from (`dbstudy`.`customer` `c` left join `dbstudy`.`orders` `o` on ((`c`.`custid` = `o`.`custid`)));

