create definer = dbuser@`%` trigger tr_orders_point_earn
    after insert
    on orders
    for each row
BEGIN 
	INSERT INTO customer_point(custid,orderid,TYPE,points,reason,created_at)
	VALUES(NEW.custid,NEW.orderid, '적립' , NEW.saleprice * 0.1 , '주문 적립', NOW());
END;

