create definer = dbuser@`%` view v_bookname2 as
select `dbstudy`.`book`.`bookname` AS `bookname`, `dbstudy`.`book`.`price` AS `price`
from `dbstudy`.`book`;

