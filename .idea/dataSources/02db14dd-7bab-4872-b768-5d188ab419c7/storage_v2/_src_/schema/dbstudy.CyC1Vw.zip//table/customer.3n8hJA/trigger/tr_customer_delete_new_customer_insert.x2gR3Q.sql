create definer = dbuser@`%` trigger tr_customer_delete_new_customer_insert
    after delete
    on customer
    for each row
BEGIN 
	INSERT INTO new_customer(NAME ,address,phone)
	VALUES(OLD.name , OLD.address,OLD.phone);
END;

