create definer = dbuser@`%` trigger tr_orders_point_cancel
    after delete
    on orders
    for each row
BEGIN 
	INSERT INTO customer_point(custid,orderid,TYPE,points,reason,created_at)
	VALUES(old.custid,old.orderid, '차감' , -old.saleprice * 0.1 , '주문 취소 차감', NOW());
END;

